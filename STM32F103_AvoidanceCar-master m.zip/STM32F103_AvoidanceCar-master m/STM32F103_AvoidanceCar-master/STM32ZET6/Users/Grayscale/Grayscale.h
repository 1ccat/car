#ifndef __GRAYSCALE_H
#define __GRAYSCALE_H

#include "main.h"
void Grayscale_Init(void);
uint8_t Grayscale_Read(uint8_t *Grayscale_Value);
int32_t Grayscale_Read_Err();
#endif // !__GRAYSCALE_H
