#include "main.h"
#include "debug.h"

#ifndef __USART_CONFIG_H
#define __USART_CONFIG_H

void USART_IT_Config(void);

#endif // !__USART_CONFIG_H


